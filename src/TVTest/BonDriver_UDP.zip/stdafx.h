#pragma once


#define _WINSOCKAPI_

#include <windows.h>

#undef _WINSOCKAPI_

#include <winsock2.h>


